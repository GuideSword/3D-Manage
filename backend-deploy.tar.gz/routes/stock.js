const express = require('express');
const router = express.Router();

// 临时模拟库存数据
const mockStockLots = [];

router.get('/lots', async (req, res) => {
  try {
    res.json({ items: mockStockLots, total: mockStockLots.length });
  } catch (error) {
    res.status(500).json({ error: '获取库存批次失败' });
  }
});

router.post('/lots', async (req, res) => {
  try {
    const newLot = { id: String(mockStockLots.length + 1), ...req.body };
    mockStockLots.push(newLot);
    res.status(201).json(newLot);
  } catch (error) {
    res.status(500).json({ error: '创建库存批次失败' });
  }
});

module.exports = router;
