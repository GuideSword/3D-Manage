const express = require('express');
const router = express.Router();

// 临时模拟物料数据
const mockMaterials = [];

router.get('/', async (req, res) => {
  try {
    res.json({ items: mockMaterials, total: mockMaterials.length });
  } catch (error) {
    res.status(500).json({ error: '获取物料列表失败' });
  }
});

router.post('/', async (req, res) => {
  try {
    const newMaterial = { id: String(mockMaterials.length + 1), ...req.body };
    mockMaterials.push(newMaterial);
    res.status(201).json(newMaterial);
  } catch (error) {
    res.status(500).json({ error: '创建物料失败' });
  }
});

module.exports = router;
